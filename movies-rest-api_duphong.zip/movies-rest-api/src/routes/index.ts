export { default as CommentRoutes } from "./comment.route";
export { default as CountryRoutes } from "./country.route";
export { default as FavoriteRoutes } from "./favorite.route";
export { default as GenreRoutes } from "./genre.route";
export { default as MovieRoutes } from "./movie.route";
export { default as RatingRoutes } from "./rating.route";
export { default as UserRoutes } from "./user.route";
