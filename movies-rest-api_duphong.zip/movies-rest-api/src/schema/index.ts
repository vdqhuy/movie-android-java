export * from "./comment.schema";
export * from "./favorite.schema";
export * from "./movie.schema";
export * from "./rating.schema";
export * from "./user.schema";
