export interface Genre {
  code: string;
  name: string;
}
