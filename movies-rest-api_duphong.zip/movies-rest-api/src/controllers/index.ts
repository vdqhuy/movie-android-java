export { default as CommentController } from "./comment.controller";
export { default as CountryController } from "./country.controller";
export { default as FavoriteController } from "./favorite.controller";
export { default as GenreController } from "./genre.controller";
export { default as MovieController } from "./movie.controller";
export { default as RatingController } from "./rating.controller";
export { default as UserController } from "./user.controller";
